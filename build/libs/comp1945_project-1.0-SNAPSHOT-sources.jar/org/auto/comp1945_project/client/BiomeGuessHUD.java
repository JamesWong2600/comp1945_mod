package org.auto.comp1945_project.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class BiomeGuessHUD implements HudRenderCallback {

    // ==================== 給 HUD 和 Web Server 的資料 ====================

    // 🔥 執行緒安全
    public static final Map<String, Double> predictedProbs = new ConcurrentHashMap<>();

    public static volatile String lastBrokenBlock = "none";
    public static volatile String lastCoord = "none";
    public static volatile String lastBiome = "none";
    public static volatile long lastTick = 0;

    private static final String[] BIOMES = {
            "project:red", "project:blue", "project:yellow"
    };

    private static final String[] BIOME_NAMES_ZH = {"紅", "藍", "黃"};
    private static final String[] BIOME_NAMES_EN = {"Red", "Blue", "Yellow"};

    // ==================== 渲染 ====================

    @Override
    public void onHudRender(class_332 drawContext, class_9779 tickCounter) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;
        if (client.field_1690.field_1842) return;

        class_327 textRenderer = client.field_1772;
        boolean useEnglish = client.field_1690.field_1883.startsWith("en");

        // 🔥 只讀，不 predict
        String coordStr = lastCoord;
        String biomeStr = lastBiome;
        long tick = lastTick;

        int leftX = 5;
        int leftY = 5;
        int lineHeight = 10;

        drawContext.method_51439(
                textRenderer,
                class_2561.method_43470(useEnglish ? "Biome Guess" : "生態域預測")
                        .method_27695(class_124.field_1065, class_124.field_1067),
                leftX, leftY, 0xFFFFFF, true
        );

        int y = leftY + lineHeight + 2;
        for (int i = 0; i < BIOMES.length; i++) {
            String biome = BIOMES[i];
            double prob = predictedProbs.getOrDefault(biome, 0.0);
            int percent = (int) Math.round(prob * 100);
            String name = useEnglish ? BIOME_NAMES_EN[i] : BIOME_NAMES_ZH[i];
            class_124 color = switch (i) {
                case 0 -> class_124.field_1061;
                case 1 -> class_124.field_1078;
                case 2 -> class_124.field_1054;
                default -> class_124.field_1068;
            };
            class_2561 line = class_2561.method_43470(name + ": ")
                    .method_27692(class_124.field_1068)
                    .method_10852(class_2561.method_43470(percent + "%").method_27692(color));
            drawContext.method_51439(textRenderer, line, leftX, y, 0xFFFFFF, true);
            y += lineHeight;
        }

        int rightX = client.method_22683().method_4486() - 5;
        int rightY = 5;
        String[] rightLines;
        if (useEnglish) {
            rightLines = new String[]{
                    "Coord: " + coordStr,
                    "Block: " + lastBrokenBlock,
                    "Tick: " + tick,
                    "Biome: " + biomeStr
            };
        } else {
            rightLines = new String[]{
                    "座標: " + coordStr,
                    "方塊: " + lastBrokenBlock,
                    "Tick: " + tick,
                    "生態域: " + biomeStr
            };
        }

        int ry = rightY;
        for (String line : rightLines) {
            int width = textRenderer.method_1727(line);
            drawContext.method_51439(
                    textRenderer,
                    class_2561.method_43470(line).method_27692(class_124.field_1075),
                    rightX - width, ry, 0xFFFFFF, true
            );
            ry += lineHeight;
        }
    }

    // ==================== 更新方法 ====================

    public static void updatePredictions(Map<String, Double> probs) {
        if (probs == null) return;
        for (String b : BIOMES) {
            predictedProbs.put(b, probs.getOrDefault(b, 0.0));
        }
    }

    public static void updateLastBrokenBlock(String blockId) {
        lastBrokenBlock = blockId;
    }

    public static void updateStatus(String coord, String biome, long tick) {
        lastCoord = coord;
        lastBiome = biome;
        lastTick = tick;
    }

    // 🔥 Web Server 用這個，回傳快照
    public static Map<String, Double> getPredictionsSnapshot() {
        Map<String, Double> snapshot = new LinkedHashMap<>();
        for (String b : BIOMES) {
            snapshot.put(b, predictedProbs.getOrDefault(b, 0.0));
        }
        return snapshot;
    }
}