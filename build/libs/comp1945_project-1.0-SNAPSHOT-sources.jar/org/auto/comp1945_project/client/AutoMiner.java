package org.auto.comp1945_project.client;

import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class AutoMiner {

    public static void mineBlock(class_3222 player, class_2338 pos) {
        class_3218 world = player.method_51469();
        // 讓玩家面向該方塊
        player.method_5702(
                net.minecraft.class_2183.class_2184.field_9851,
                net.minecraft.class_243.method_24953(pos)
        );
        // 直接破壞
        world.method_8651(pos, true, player);
    }
}