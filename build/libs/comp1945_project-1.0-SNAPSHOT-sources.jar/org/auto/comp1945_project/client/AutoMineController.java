package org.auto.comp1945_project.client;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1934;
import net.minecraft.class_2170;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2535;
import net.minecraft.class_2561;
import net.minecraft.class_2598;
import net.minecraft.class_2626;
import net.minecraft.class_2680;
import net.minecraft.class_2703;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_6088;
import net.minecraft.class_7923;
import net.minecraft.class_8791;
import net.minecraft.class_8792;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;


public class AutoMineController extends class_3222 {

    private static AutoMineController fakePlayer;
    private static int radius = 16;
    private static int tickCounter = 0;
    private static boolean enabled = true;
    private static class_2338 currentTarget = null;
    private static int wanderTicks = 0;
    private static class_243 wanderDir = null;
    private static final int WANDER_MIN = 40;   // 最少走 2 秒
    private static final int WANDER_MAX = 100;  // 最多走 5 秒
    private static final double WANDER_STEP = 0.4;
    private static final double WANDER_SPEED = 0.4;

    // ==================== 建構子 ====================

    public AutoMineController(MinecraftServer server, class_3218 world, GameProfile profile, class_8791 clientOptions) {
        super(server, world, profile, clientOptions);
    }

    @Override
    public boolean method_7325() {
        return false;
    }

    @Override
    public boolean method_7337() {
        return false;
    }

    // ==================== 註冊 ====================

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            // 1. 記錄 ans_key_data
            for (class_3222 player : server.method_3760().method_14571()) {
                if (player.method_37908() instanceof class_3218 world) {
                    MiningRecordManager.tickAnsKey(world, player.method_23317(), player.method_23318(), player.method_23321());
                }
            }
            MiningRecordManager.tickFlush();

            // 2. 假玩家邏輯
            if (!enabled) return;
            AutoMineController fake = getFakePlayer();
            if (fake == null) return;

            class_3218 world = fake.method_51469();

            // 如果目標被挖掉了，清掉
            if (currentTarget != null && world.method_8320(currentTarget).method_26215()) {
                currentTarget = null;
            }

            if (currentTarget != null) {
                // 有目標：走過去挖
                double dist = fake.method_19538().method_1022(class_243.method_24953(currentTarget));
                if (dist > 4.0) {
                    fake.moveTowards(currentTarget);
                } else {
                    fake.breakBlockAt(currentTarget);
                    currentTarget = null;
                }
            } else {
                // 沒有目標：隨機漫遊
                if (wanderTicks <= 0 || wanderDir == null) {
                    double angle = Math.random() * Math.PI * 2;
                    wanderDir = new class_243(Math.cos(angle), 0, Math.sin(angle)).method_1029();
                    wanderTicks = WANDER_MIN + (int)(Math.random() * (WANDER_MAX - WANDER_MIN));
                }

                class_243 current = fake.method_19538();
                class_243 next = current.method_1019(wanderDir.method_1021(WANDER_STEP));

                // 檢查前方是不是空氣，避免穿牆
                class_2338 check = class_2338.method_49637(next.field_1352, next.field_1351, next.field_1350);
                if (world.method_8320(check).method_26215()
                        && world.method_8320(check.method_10084()).method_26215()) {
                    fake.method_5814(next.field_1352, next.field_1351, next.field_1350);
                    fake.method_24203(next.field_1352, next.field_1351, next.field_1350);
                    fake.lookAtOre(class_2338.method_49638(next));
                } else {
                    // 撞牆就換方向
                    wanderDir = null;
                    wanderTicks = 0;
                }

                wanderTicks--;

                // 邊走邊找礦（半徑 8）
                class_2338 ore = OreFinder.findNearestOre(world, fake.method_19538(), 8);
                if (ore != null) {
                    currentTarget = ore;
                    wanderDir = null;
                    wanderTicks = 0;
                }
            }

            // 3. 更新 HUD 狀態
            class_2338 pos = fake.method_24515();
            String coordStr = pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260();
            String biomeStr = world.method_23753(pos).method_40230()
                    .map(key -> key.method_29177().toString())
                    .orElse("minecraft:plains");
            long tick = world.method_8510();
            BiomeGuessHUD.updateStatus(coordStr, biomeStr, tick);

            // 4. 每 200 tick 非同步訓練一次
            if (server.method_3780() % 200 == 0) {
                HMMBiomeTrainer.trainAsync();
            }

            // 5. 更新預測
            Map<String, Double> probs = HMMBiomeTrainer.predict(fake.method_5667());
            BiomeGuessHUD.updatePredictions(probs);
            BiomeHistory.add(tick, probs);
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                    class_2170.method_9247("fakemine")
                            .requires(source -> source.method_9259(2))
                            .then(class_2170.method_9247("spawn")
                                    .executes(context -> {
                                        class_3222 sourcePlayer = context.getSource().method_44023();
                                        if (sourcePlayer == null) {
                                            context.getSource().method_9213(class_2561.method_43470("必須由玩家執行"));
                                            return 0;
                                        }
                                        class_3218 world = sourcePlayer.method_51469();
                                        class_2338 pos = sourcePlayer.method_24515();
                                        AutoMineController.spawn(world, sourcePlayer.method_5667(), pos);
                                        context.getSource().method_9226(
                                                () -> class_2561.method_43470("已生成假玩家於 " + pos.method_23854() + " 並自動開始尋找礦石"),
                                                false
                                        );
                                        return 1;
                                    })
                            )
                            .then(class_2170.method_9247("remove")
                                    .executes(context -> {
                                        if (fakePlayer != null) {
                                            fakePlayer.method_31472();
                                            fakePlayer = null;
                                            context.getSource().method_9226(
                                                    () -> class_2561.method_43470("已移除假玩家並停止自動挖礦"),
                                                    false
                                            );
                                        } else {
                                            context.getSource().method_9213(class_2561.method_43470("沒有假玩家"));
                                        }
                                        return 1;
                                    })
                            )
                            .then(class_2170.method_9247("radius")
                                    .then(class_2170.method_9244("value", IntegerArgumentType.integer(1, 64))
                                            .executes(context -> {
                                                radius = IntegerArgumentType.getInteger(context, "value");
                                                context.getSource().method_9226(
                                                        () -> class_2561.method_43470("尋礦半徑已設為: " + radius),
                                                        false
                                                );
                                                return 1;
                                            })
                                    )
                            ).then(class_2170.method_9247("train")
                                    .executes(context -> {
                                        BiomePredictor.Model model = BiomeTrainer.train();   // ← 這裡呼叫
                                        if (model == null) {
                                            context.getSource().method_9213(class_2561.method_43470("訓練失敗，資料不足"));
                                            return 0;
                                        }
                                        BiomePredictor.load();   // ← 這裡呼叫
                                        context.getSource().method_9226(
                                                () -> class_2561.method_43470("模型訓練完成"),
                                                false
                                        );
                                        return 1;
                                    })
                            ).then(class_2170.method_9247("predict")
                                    .executes(context -> {
                                        if (!BiomePredictor.isLoaded()) {   // ← 這裡呼叫
                                            context.getSource().method_9213(class_2561.method_43470("模型尚未載入，請先 /fakemine train"));
                                            return 0;
                                        }

                                        Map<String, Integer> oreCounts = SessionStats.get(context.getSource().method_44023().method_5667());
                                        Map<String, Double> probs = BiomePredictor.predict(oreCounts);   // ← 這裡呼叫

                                        for (Map.Entry<String, Double> e : probs.entrySet()) {
                                            String line = e.getKey() + ": " + String.format("%.2f%%", e.getValue() * 100);
                                            context.getSource().method_9226(() -> class_2561.method_43470(line), false);
                                        }
                                        return 1;
                                    })
                            )
            );
        });
    }

    // ==================== 生成 ====================

    public static AutoMineController spawn(class_3218 world, UUID ownerUuid, class_2338 pos) {
        MinecraftServer server = world.method_8503();
        if (server == null) {
            System.err.println("[AutoMine] ❌ Server 為空");
            return null;
        }

        UUID cloneUuid = UUID.nameUUIDFromBytes(("Z_CLONE_ENTITY:" + ownerUuid).getBytes());

        Optional<GameProfile> existingProfile = server.method_3793().method_14512(ownerUuid);
        String name = existingProfile.map(GameProfile::getName).orElse("Miner");
        GameProfile profile = new GameProfile(cloneUuid, "§z_" + name);
        existingProfile.ifPresent(p -> profile.getProperties().putAll(p.getProperties()));

        AutoMineController npc = new AutoMineController(
                server, world, profile, class_8791.method_53821()
        );
        npc.method_5808(
                pos.method_10263() + 0.5,
                pos.method_10264(),
                pos.method_10260() + 0.5,
                0.0F,
                0.0F
        );

        npc.method_5684(true);
        npc.method_5648(false);
        npc.method_5803(true);

        // 🛑 關閉重力，避免假玩家受重力影響往下掉
        npc.method_5875(true);

        npc.method_5841().method_12778(
                net.minecraft.class_1657.field_7518,
                (byte) 0x7F
        );

        class_2535 fakeConn = new class_2535(class_2598.field_11941);
        npc.field_13987 = new class_3244(
                server,
                fakeConn,
                npc,
                new class_8792(profile, 0, npc.method_53823(), false)
        );

        server.method_3760().method_14571().add(npc);
        server.method_3760().method_14581(
                class_2703.method_43886(List.of(npc))
        );

        world.method_8649(npc);
        npc.field_13974.method_30118(class_1934.field_9215);

        fakePlayer = npc;
        System.out.println("[AutoMine] ✅ NPC 已生成在 " + pos + " 並開始自動挖礦");
        return npc;
    }

    // ==================== 直線移動與轉頭控制 ====================

    public void moveTowards(class_2338 pos) {
        class_243 target = new class_243(pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5);
        class_243 current = this.method_19538();
        class_243 direction = target.method_1020(current).method_1029().method_1021(0.4); // 0.4 為移動步長

        // 瞬間轉頭面向目標
        this.lookAtOre(pos);

        // 更新位置（直接朝目標前進）
        this.method_5814(current.field_1352 + direction.field_1352, current.field_1351 + direction.field_1351, current.field_1350 + direction.field_1350);
        this.method_24203(this.method_23317(), this.method_23318(), this.method_23321());
    }

    public void lookAtOre(class_2338 pos) {
        double dx = pos.method_10263() + 0.5 - this.method_23317();
        double dy = pos.method_10264() + 0.5 - this.method_23320();
        double dz = pos.method_10260() + 0.5 - this.method_23321();
        double distance = Math.sqrt(dx * dx + dz * dz);

        float yaw = (float) (Math.atan2(dz, dx) * (180 / Math.PI)) - 90.0F;
        float pitch = (float) (-(Math.atan2(dy, distance) * (180 / Math.PI)));

        this.method_36456(yaw);
        this.method_36457(pitch);
        this.field_6241 = yaw;
    }

    // ==================== 挖礦 ====================

    public void breakBlockAt(class_2338 pos) {
        class_3218 world = this.method_51469();
        class_2680 state = world.method_8320(pos);
        if (state.method_26215()) return;

        String oreId = class_7923.field_41175.method_10221(state.method_26204()).toString();
        System.out.println("[AutoMine] 挖到方塊: " + oreId);

        String biomeId = world.method_23753(pos).method_40230()
                .map(key -> key.method_29177().toString())
                .orElse("minecraft:plains");

        BiomeTrainerLive.onBlockBreak(oreId, biomeId);

        HMMBiomeTrainer.onBlockBreak(this.method_5667(), oreId);


        MiningRecordManager.recordBlockBreak(world, pos, state);
        class_2960 blockId = class_7923.field_41175.method_10221(state.method_26204());
        BiomeGuessHUD.updateLastBrokenBlock(blockId.toString());
        this.method_31549().field_7476 = true;

        class_3414 breakSound = state.method_26231().method_10595();
        world.method_8396(null, pos, breakSound, class_3419.field_15245, 1.0f, 1.0f);

        world.method_8652(
                pos,
                class_2246.field_10124.method_9564(),
                net.minecraft.class_2248.field_31036 | net.minecraft.class_2248.field_31031
        );

        world.method_14178().method_14128(pos);

        class_2626 packet = new class_2626(world, pos);
        for (class_3222 viewer : world.method_8503().method_3760().method_14571()) {
            viewer.field_13987.method_14364(packet);
        }

        world.method_8503().execute(() -> {
            world.method_14178().method_14128(pos);
            class_2626 packet2 = new class_2626(world, pos);
            for (class_3222 viewer : world.method_8503().method_3760().method_14571()) {
                viewer.field_13987.method_14364(packet2);
            }
        });

        world.method_20290(
                class_6088.field_31144,
                pos,
                net.minecraft.class_2248.method_9507(state)
        );

        System.out.println("[AutoMine] 🔨 破壞: " + pos);
    }

    // ==================== 移除 ====================

    @Override
    public void method_5650(class_5529 reason) {
        if (this.method_5682() != null) {
            this.method_5682().method_3760().method_14571().remove(this);
        }
        if (fakePlayer == this) {
            fakePlayer = null;
            currentTarget = null;   // 🔥 加這行
        }
        super.method_5650(reason);
    }

    // ==================== Getter ====================

    public static AutoMineController getFakePlayer() {
        return fakePlayer;
    }

    public static int getRadius() {
        return radius;
    }
}