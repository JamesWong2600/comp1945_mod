package org.auto.comp1945_project.client;


import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7923;

public class OreFinder {

    private static final Set<class_2248> ORES = new HashSet<>();

    static {
        // 原版礦石（可選）
        ORES.add(class_2246.field_10381);
        //ORES.add(Blocks.DEEPSLATE_COAL_ORE);
        ORES.add(class_2246.field_10085);
        //ORES.add(Blocks.DEEPSLATE_IRON_ORE);
        ORES.add(class_2246.field_10205);
       // ORES.add(Blocks.DEEPSLATE_GOLD_ORE);
        ORES.add(class_2246.field_10201);
       // ORES.add(Blocks.DEEPSLATE_DIAMOND_ORE);
        ORES.add(class_2246.field_10234);
       // ORES.add(Blocks.DEEPSLATE_EMERALD_ORE);
        ORES.add(class_2246.field_10002);
       // ORES.add(Blocks.DEEPSLATE_REDSTONE_ORE);
//
//        // 你自訂的方塊
//        addBlock("project:coal_block");
//        addBlock("project:diamond_block");
//        addBlock("project:emerald_block");
//        addBlock("project:gold_block");
//        addBlock("project:iron_block");
//        addBlock("project:redstone_block");
    }

    private static void addBlock(String id) {
        class_2248 block = class_7923.field_41175.method_63535(class_2960.method_60654(id));
        if (block != class_2246.field_10124) {
            ORES.add(block);
        } else {
            System.out.println("[OreFinder] 找不到方塊: " + id);
        }
    }

    public static class_2338 findNearestOre(class_3218 world, class_243 center, int radius) {
        class_2338 centerPos = class_2338.method_49638(center);
        class_2338 nearest = null;
        double nearestDist = Double.MAX_VALUE;

        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    class_2338 pos = centerPos.method_10069(x, y, z);
                    class_2248 block = world.method_8320(pos).method_26204();
                    if (ORES.contains(block)) {
                        double dist = center.method_1028(
                                pos.method_10263() + 0.5,
                                pos.method_10264() + 0.5,
                                pos.method_10260() + 0.5
                        );
                        if (dist < nearestDist) {
                            nearestDist = dist;
                            nearest = pos;
                        }
                    }
                }
            }
        }
        return nearest;
    }
}